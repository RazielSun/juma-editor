#ifndef POINT_H
#define POINT_H

namespace geometry {

    struct Point
    {
        double x;
        double y;
        int color;
    };
}

#endif
